import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Program
{
    public static void main(String[] args)
    {
        //Run The Program
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        int[] arr;
        int arrLength;

        System.out.println("Enter number of array: ");

        arrLength  = checkIntegerInput(sc);
        arr = new int[arrLength];

        for (int i = 0; i < arrLength; i++)
        {
            arr[i] = random.nextInt(1, arrLength);
        }

        System.out.println("Unsorted array: " + Arrays.toString(arr));
        
        bubbleSortFunc(arr);
        
        System.out.print("Sorted array: " + Arrays.toString(arr));
    }

    static int checkIntegerInput(Scanner sc)
    {
        int arrLength;

        while (true)
        {
            if (sc.hasNextInt())
            {
                arrLength = sc.nextInt();
                sc.nextLine();

                return arrLength;
            }

            System.out.printf("%nInvalid input !!!%n%n");
            sc.next();
        }
    }

    static void bubbleSortFunc(int[] arr)
    {
        boolean haveSwap;
        int tmp;
        int arrLength = arr.length;

        for (int i = 0; i < arrLength - 1; i++)
        {
            haveSwap = false;

            for (int j = 0; j < arrLength - i - 1; j++)
            {
                if (arr[j] > arr[j + 1])
                {
                    tmp = arr[j];
                    arr[j] =  arr[j + 1];
                    arr[j + 1] = tmp;

                    haveSwap = true;
                }
            }

            if (!haveSwap)
            {
                return;
            }
        }
    }
}
